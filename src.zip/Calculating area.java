abstract class Shape{
    public double S;
    public abstract void work();
}

class triangle extends Shape{
    public double a;
    public double h;
    public triangle (double a,double h){
        this.a=a;
        this.h=h;
    }
    public void work(){
        S=0.5*(a+h);
        System.out.println("三角形的面积:"+S);
    }
}
class  Square extends Shape{
    public double a;
    public double b;
    public Square(double a,double b){
        this.a=a;
        this.b=b;
    }
    public void work(){
        S=a*b;
        System.out.println("正方形的面积是:"+S);
    }
}

class Circular extends Shape{
    public double r;
    public Circular(double r){
        this.r=r;
    }
    @Override
    public void work() {
        S=0.5*3.14*r*r;
        System.out.println("圆的面积是:"+S);
    }
}