public class Work{
    public static void main(String[] args) {
        triangle s1 = new triangle(1.5,5);
        s1.work();
        Square s2 = new Square(2.0,5);
        s2.work();
        Circular s3 = new Circular(2);
        s3.work();
    }
}